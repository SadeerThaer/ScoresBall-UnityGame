﻿using System.Collections;
using UnityEngine;

public class Coints : MonoBehaviour
{
    
    public static float vertVel = 0;
    public static int coinTotal = 0; 
    public static float timeTotal = 0;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
